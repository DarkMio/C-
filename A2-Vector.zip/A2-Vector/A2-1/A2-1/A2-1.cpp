// A2-1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "my_vector.h"
#include <iostream>

using namespace std;

void test_21();


int main() {
	cout << "Starting tests (2.1) --------------------" << endl;
	test_21();

	// cout << "Starting tests (2.2) --------------------" << endl;
	// test22();

	cout << "End of tests ----------------------------" << endl;

	return 0;
}
