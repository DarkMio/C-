#pragma once
#include <iostream>
#include <cassert>
#include "my_vector.h"
#include "payload.h"

void test_21();